﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace DSP
{
    public partial class SmallModel : Form
    {
        Form1 Parent;
        //глобальные textbox
        TextBox nbox;
        TextBox fdbox;
        TextBox n0box;
        TextBox abox;
        TextBox wbox;
        TextBox fibox;
        TextBox lbox;
        TextBox tbox;
        TextBox fbox;
        TextBox fobox;
        TextBox fnbox;
        TextBox mbox;
        TextBox fkbox;
        TextBox Tbox;
        public SmallModel(Form1 ParentForm)
        {
            InitializeComponent();
            Parent = ParentForm;
        }
        private void shablon(int h, int w, string s, int okx, int oky)
        {
            this.Height = h;
            this.Width = w;
            Label labelname = new Label();
            labelname.Location = new Point(12, 10);
            labelname.Text = s;
            labelname.Size = new Size(this.Width - 13, 20);
            labelname.Font = new Font(labelname.Font, labelname.Font.Style | FontStyle.Bold);
            this.Controls.Add(labelname);
            Label n = new Label();
            n.Location = new Point(12, 40);
            n.Text = "Количество отсчётов n:";
            n.Size = new Size(this.Width - 13, 20);
            this.Controls.Add(n);
            nbox = new TextBox();
            nbox.Text = Holder.SamplesNumber.ToString();
            nbox.Location = new Point(13, 60);
            nbox.Size = new Size(this.Width - 39, 20);
            this.Controls.Add(nbox);
            Label fd = new Label();
            fd.Location = new Point(12, 85);
            fd.Text = "Частота дискретизации fd:";
            fd.Size = new Size(this.Width - 13, 20);
            this.Controls.Add(fd);
            fdbox = new TextBox();
            fdbox.Text = Holder.SamplingRate.ToString();
            fdbox.Location = new Point(13, 105);
            fdbox.Size = new Size(this.Width - 39, 20);
            this.Controls.Add(fdbox);
            Button okay = new Button();
            okay.Size = new Size(80, 30);
            okay.Text = "ОК";
            okay.Location = new Point(okx, oky);
            this.Controls.Add(okay);
            okay.Click += Ok_Click;
        }
        private void fillwindow12(string s, string s1)
        {
            this.shablon(270, 250, s, 13, 190);
            Label n0 = new Label();
            n0.Location = new Point(13, 130);
            n0.Text = s1;
            n0.Size = new Size(this.Width - 13, 20);
            this.Controls.Add(n0);
            n0box = new TextBox();
            n0box.Location = new Point(13, 150);
            n0box.Size = new Size(this.Width - 39, 20);
            this.Controls.Add(n0box);
        }
        private void fillwindow56(string s)
        {
            this.shablon(270, 200, s, 13, 190);
            Label l = new Label();
            l.Location = new Point(13, 130);
            l.Text = "Период L:";
            l.Size = new Size(this.Width - 13, 20);
            this.Controls.Add(l);
            lbox = new TextBox();
            lbox.Location = new Point(13, 150);
            lbox.Size = new Size(this.Width - 39, 20);
            this.Controls.Add(lbox);
        }
        private void SmallModel_Load(object sender, EventArgs e)
        {
            if (Holder.check == 1)
            {
                this.fillwindow12("Задержанный единичный импульс", "Задержка импульса n0:");
            }
            else if (Holder.check == 2)
            {
                this.fillwindow12("Задержанный единичный скачок", "Задержка скачка n0:");
            }
            else if (Holder.check == 3)
            {
                this.shablon(270, 320, "Дискретизированная убывающая экспонента", 13, 190);
                Label a = new Label();
                a.Location = new Point(13, 130);
                a.Text = "Амплитуда 0 < a < 1:";
                a.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(a);
                abox = new TextBox();
                abox.Location = new Point(13, 150);
                abox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(abox);
            }
            else if (Holder.check == 4)
            {
                this.shablon(360, 240, "Дискретизированная синусоида", 13, 280);
                Label a = new Label();
                a.Location = new Point(13, 130);
                a.Text = "Амплитуда 0 < a < 1:";
                a.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(a);
                abox = new TextBox();
                abox.Location = new Point(13, 150);
                abox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(abox);

                Label w = new Label();
                w.Location = new Point(13, 175);
                w.Text = "Круговая частота 0 <= w <= pi:";
                w.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(w);
                wbox = new TextBox();
                wbox.Location = new Point(13, 195);
                wbox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(wbox);

                Label fi = new Label();
                fi.Location = new Point(13, 220);
                fi.Text = "Начальная фаза 0 <= fi <= 2pi:";
                fi.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(fi);
                fibox = new TextBox();
                fibox.Location = new Point(13, 240);
                fibox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fibox);
            }
            else if (Holder.check == 5)
            {
                this.fillwindow56("Меандр");
            }
            else if (Holder.check == 6)
            {
                this.fillwindow56("Пила");
            }
            else if (Holder.check == 7)
            {
                this.shablon(405, 283, "Сигнал с экспоненциальной огибающей", 13, 325);
                Label a = new Label();
                a.Location = new Point(13, 130);
                a.Text = "Амплитуда 0 < a < 1:";
                a.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(a);
                abox = new TextBox();
                abox.Location = new Point(13, 150);
                abox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(abox);

                Label t = new Label();
                t.Location = new Point(13, 175);
                t.Text = "Параметр ширины огибающей t:";
                t.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(t);
                tbox = new TextBox();
                tbox.Location = new Point(13, 195);
                tbox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(tbox);

                Label f = new Label();
                f.Location = new Point(13, 220);
                f.Text = "Частота несущей 0 <= f <= 0.5fd:";
                f.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(f);
                fbox = new TextBox();
                fbox.Location = new Point(13, 240);
                fbox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fbox);

                Label fi = new Label();
                fi.Location = new Point(13, 265);
                fi.Text = "Начальная фаза 0 <= fi <= 2pi:";
                fi.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(fi);
                fibox = new TextBox();
                fibox.Location = new Point(13, 285);
                fibox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fibox);
            }
            else if (Holder.check == 8)
            {
                this.shablon(405, 233, "Сигнал с балансной огибающей", 13, 325);
                Label a = new Label();
                a.Location = new Point(13, 130);
                a.Text = "Амплитуда 0 < a < 1:";
                a.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(a);
                abox = new TextBox();
                abox.Location = new Point(13, 150);
                abox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(abox);

                Label fo = new Label();
                fo.Location = new Point(13, 175);
                fo.Text = "Частота огибающей 0 <= fo <= 0.5fd:";
                fo.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(fo);
                fobox = new TextBox();
                fobox.Location = new Point(13, 195);
                fobox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fobox);

                Label fn = new Label();
                fn.Location = new Point(13, 220);
                fn.Text = "Частота несущей 0 <= fn <= 0.5fd:";
                fn.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(fn);
                fnbox = new TextBox();
                fnbox.Location = new Point(13, 240);
                fnbox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fnbox);

                Label fi = new Label();
                fi.Location = new Point(13, 265);
                fi.Text = "Начальная фаза 0 <= fi <= 2pi:";
                fi.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(fi);
                fibox = new TextBox();
                fibox.Location = new Point(13, 285);
                fibox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fibox);
            }
            else if (Holder.check == 9)
            {
                this.shablon(450, 243, "Сигнал с тональной огибающей", 13, 370);
                Label a = new Label();
                a.Location = new Point(13, 130);
                a.Text = "Амплитуда 0 < a < 1:";
                a.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(a);
                abox = new TextBox();
                abox.Location = new Point(13, 150);
                abox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(abox);

                Label fo = new Label();
                fo.Location = new Point(13, 175);
                fo.Text = "Частота огибающей 0 <= fo <= 0.5fd:";
                fo.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(fo);
                fobox = new TextBox();
                fobox.Location = new Point(13, 195);
                fobox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fobox);

                Label fn = new Label();
                fn.Location = new Point(13, 220);
                fn.Text = "Частота несущей 0 <= fn <= 0.5fd:";
                fn.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(fn);
                fnbox = new TextBox();
                fnbox.Location = new Point(13, 240);
                fnbox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fnbox);

                Label fi = new Label();
                fi.Location = new Point(13, 265);
                fi.Text = "Начальная фаза 0 <= fi <= 2pi:";
                fi.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(fi);
                fibox = new TextBox();
                fibox.Location = new Point(13, 285);
                fibox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fibox);

                Label m = new Label();
                m.Location = new Point(13, 310);
                m.Text = "Индекс глубины модуляции 0 <= m <= 1:";
                m.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(m);
                mbox = new TextBox();
                mbox.Location = new Point(13, 330);
                mbox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(mbox);
            }
            else if (Holder.check == 10)
            {
                this.shablon(450, 296, "Сигнал с линейной частотной модуляцией", 13, 370);
                Label a = new Label();
                a.Location = new Point(13, 130);
                a.Text = "Амплитуда 0 < a < 1:";
                a.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(a);
                abox = new TextBox();
                abox.Location = new Point(13, 150);
                abox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(abox);

                Label fo = new Label();
                fo.Location = new Point(13, 175);
                fo.Text = "Частота в начальный момент времени f0 (t = 0):";
                fo.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(fo);
                fobox = new TextBox();
                fobox.Location = new Point(13, 195);
                fobox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fobox);

                Label fk = new Label();
                fk.Location = new Point(13, 220);
                fk.Text = "Частота в конечный момент времени fk:";
                fk.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(fk);
                fkbox = new TextBox();
                fkbox.Location = new Point(13, 240);
                fkbox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fkbox);

                Label T = new Label();
                T.Location = new Point(13, 265);
                T.Text = "Т наблюдения = NT:";
                T.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(T);
                Tbox = new TextBox();
                Tbox.Text = "-";
                Tbox.Location = new Point(13, 285);
                Tbox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(Tbox);

                Label fi = new Label();
                fi.Location = new Point(13, 310);
                fi.Text = "Начальная фаза 0 <= fi <= 2pi:";
                fi.Size = new Size(this.Width - 13, 20);
                this.Controls.Add(fi);
                fibox = new TextBox();
                fibox.Location = new Point(13, 330);
                fibox.Size = new Size(this.Width - 39, 20);
                this.Controls.Add(fibox);
            }
        }

        private void Ok_Click(object sender, EventArgs e)
        {
            if (int.Parse(nbox.Text) != Holder.SamplesNumber) //100 = Holder.n из холдер
            {
                //количество изменилось
                Holder.SamplesNumber = int.Parse(nbox.Text);
                //как-нибудь пометить это флагом
                Holder.flagSamples = true;
            }
            if (float.Parse(fdbox.Text, CultureInfo.InvariantCulture.NumberFormat) != Holder.SamplingRate) //12 = Holder.fd из холдер
            {
                //частота изменилось
                Holder.SamplingRate = float.Parse(fdbox.Text, CultureInfo.InvariantCulture.NumberFormat);
                //как-нибудь пометить это флагом
                Holder.flagRate = true;
            }
            if (Holder.check == 1 || Holder.check == 2)
            {
                //записать глобальные в холдер
                Holder.n0 = int.Parse(n0box.Text);
                Model model = new Model(Parent);
                model.MdiParent = Parent;
                model.Show();
            }
            else if (Holder.check == 3)
            {
                //записать глобальные в холдер
                Holder.a = double.Parse(abox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Model model = new Model(Parent);
                model.MdiParent = Parent;
                model.Show();
            }
            else if (Holder.check == 4)
            {
                //записать глобальные в холдер
                Holder.a = double.Parse(abox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.w = double.Parse(wbox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.fi = double.Parse(fibox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Model model = new Model(Parent);
                model.MdiParent = Parent;
                model.Show();
            }
            else if (Holder.check == 5 || Holder.check == 6)
            {
                //записать глобальные в холдер
                Holder.l = int.Parse(lbox.Text);
                Model model = new Model(Parent);
                model.MdiParent = Parent;
                model.Show();
            }
            else if (Holder.check == 7)
            {
                //записать глобальные в холдер
                Holder.a = double.Parse(abox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.t = int.Parse(tbox.Text);
                Holder.f = double.Parse(fbox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.fi = double.Parse(fibox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Model model = new Model(Parent);
                model.MdiParent = Parent;
                model.Show();
            }
            else if (Holder.check == 8)
            {
                //записать глобальные в холдер
                Holder.a = double.Parse(abox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.fo = double.Parse(fobox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.fn = double.Parse(fnbox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.fi = double.Parse(fibox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Model model = new Model(Parent);
                model.MdiParent = Parent;
                model.Show();
            }
            else if (Holder.check == 9)
            {
                //записать глобальные в холдер
                Holder.a = double.Parse(abox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.fo = double.Parse(fobox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.fn = double.Parse(fnbox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.fi = double.Parse(fibox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.m = double.Parse(mbox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Model model = new Model(Parent);
                model.MdiParent = Parent;
                model.Show();
            }
            else if (Holder.check == 10)
            {
                //записать глобальные в холдер
                Holder.a = double.Parse(abox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.fo = double.Parse(fobox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.fk = double.Parse(fkbox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Holder.T = Holder.SamplesNumber * Holder.SamplingRate;
                Holder.fi = double.Parse(fibox.Text, CultureInfo.InvariantCulture.NumberFormat);
                Model model = new Model(Parent);
                model.MdiParent = Parent;
                model.Show();
            }
        }
    }
}
