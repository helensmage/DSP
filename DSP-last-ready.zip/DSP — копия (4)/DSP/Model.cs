﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Drawing.Drawing2D;

namespace DSP
{
    public partial class Model : Form
    {
        Form1 Parent;
        Chart chart;
        int[] counts;
        double[] countsY;
        public Model(Form1 ParentForm)
        {
            InitializeComponent();
            Parent = ParentForm;
        }
        private void CreateChart()
        {
            chart = new Chart();
            chart.Parent = this;
            chart.SetBounds(0, 20, ClientSize.Width, ClientSize.Height - 20);
            ChartArea area = new ChartArea();
            area.Name = "myGraph";
            area.AxisY.Minimum = countsY.Min();
            area.AxisY.Maximum = countsY.Max();
            area.AxisX.Minimum = 0;
            area.AxisX.Maximum = Holder.SamplesNumber;
            area.AxisX.MajorGrid.LineColor = Color.Gray;
            area.AxisY.MajorGrid.LineColor = Color.Gray;
            area.AxisX.MajorGrid.Enabled = !Holder.grid;
            area.AxisY.MajorGrid.Enabled = !Holder.grid;
            area.AxisY.LabelStyle.Format = "N1";
            area.AxisX.LabelStyle.Format = "N0";
            area.AxisX.ScrollBar.Enabled = true;
            area.CursorX.IsUserEnabled = true;
            area.CursorX.IsUserSelectionEnabled = true;
            area.CursorX.Interval = 0;
            area.AxisX.ScaleView.Zoomable = true;
            area.AxisX.ScrollBar.IsPositionedInside = true;
            area.BorderDashStyle = ChartDashStyle.Solid;
            area.BorderColor = Color.Black;
            area.BorderWidth = 1;
            area.Position.Y = 20;
            area.Position.Height = 80;
            area.Position.Width = 100;
            area.Position.X = 0;
            chart.ChartAreas.Add(area);
            Series series1 = new Series();
            if (Holder.dots) series1.MarkerStyle = MarkerStyle.Circle;
            series1.Color = Color.Black;
            series1.ChartArea = "myGraph";
            series1.ChartType = SeriesChartType.Line;
            series1.LegendText = "Model_" + Holder.check + "_1";
            chart.Legends.Add("Model_" + Holder.check + "_1");
            chart.Legends[0].Position.Auto = false;
            chart.Legends[0].Position = new ElementPosition(0, 0, 100, 20);
            chart.Series.Add(series1);
            //area.AxisX.ScaleView.Zoom(Holder.zoomX, Holder.zoomY);
        }
        private void Model_Load(object sender, EventArgs e)
        {
            counts = new int[Holder.SamplesNumber];
            for (int count = 0; count < Holder.SamplesNumber; count++)
            {
                counts[count] = count;
            }
            countsY = new double[Holder.SamplesNumber];
            if (Holder.check == 1)
            {
                for (int count = 0; count < Holder.SamplesNumber; count++)
                {
                    countsY[count] = 0;
                }
                countsY[Holder.n0] = 1;
            }
            else if (Holder.check == 2)
            {
                for (int count = 0; count < Holder.SamplesNumber; count++)
                {
                    if (count >= Holder.n0)
                    {
                        countsY[count] = 1;
                    }
                    else
                    {
                        countsY[count] = 0;
                    }
                }
            }
            else if (Holder.check == 3)
            {
                for (int count = 0; count < Holder.SamplesNumber; count++)
                {
                    countsY[count] = Math.Pow(Holder.a, count);
                }
            }
            else if (Holder.check == 4)
            {
                for (int count = 0; count < Holder.SamplesNumber; count++)
                {
                    countsY[count] = Holder.a * Math.Sin(count * Holder.w + Holder.fi);
                }
            }
            else if (Holder.check == 5)
            {
                for (int count = 0; count < Holder.SamplesNumber; count++)
                {
                    if (count % Holder.l < (Holder.l / 2))
                    {
                        countsY[count] = 1;
                    }
                    else
                    {
                        countsY[count] = -1;
                    }
                }
            }
            else if (Holder.check == 6)
            {
                for (int count = 0; count < Holder.SamplesNumber; count++)
                {
                    countsY[count] = (double)(count % Holder.l) / Holder.l;
                }
            }
            else if (Holder.check == 7)
            {
                for (int count = 0; count < Holder.SamplesNumber; count++)
                {
                    countsY[count] = Holder.a * Math.Exp(-count / Holder.t) * Math.Cos(2 * Math.PI * Holder.f * count + Holder.fi);
                }
            }
            else if (Holder.check == 8)
            {
                for (int count = 0; count < Holder.SamplesNumber; count++)
                {
                    countsY[count] = Holder.a * Math.Cos(2 * Math.PI * Holder.fo * count) * Math.Cos(2 * Math.PI * Holder.fn * count + Holder.fi);
                }
            }
            else if (Holder.check == 9)
            {
                for (int count = 0; count < Holder.SamplesNumber; count++)
                {
                    countsY[count] = Holder.a * (1 + Holder.m * Math.Cos(2 * Math.PI * Holder.fo * count)) * Math.Cos(2 * Math.PI * Holder.fn * count + Holder.fi);
                }
            }
            else if (Holder.check == 10)
            {
                for (int count = 0; count < Holder.SamplesNumber; count++)
                {
                    countsY[count] = Holder.a * Math.Cos(2 * Math.PI * (Holder.fo + (Holder.fk - Holder.fo) / Holder.T * count) * count + Holder.fi);
                }
            }
            CreateChart();
            chart.Series[0].Points.DataBindXY(counts, countsY);
            chart.MouseDown += new MouseEventHandler(this.DeleteChart);
            this.ClientSizeChanged += Control1_ClientSizeChanged;
        }
        private void DeleteChart(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                chart = sender as Chart;
            }
        }
        private void Control1_ClientSizeChanged(Object sender, EventArgs e)
        {
            chart.Width = this.ClientSize.Width;
            chart.Height = this.ClientSize.Height - 20;
        }
        private void MapRectangles(Graphics gr,
             float wxmin, float wxmax, float wymin, float wymax,
             float dxmin, float dxmax, float dymin, float dymax)
        {
            RectangleF wrectf;
            if (wymax - wymin != 0)
            {
                wrectf = new RectangleF(wxmin, wymin, wxmax - wxmin, wymax - wymin);
            }
            else
            {
                wrectf = new RectangleF(wxmin, wymin * wymin * (-1000), wxmax - wxmin, wxmax - wxmin);
            }
            PointF[] dpts = {
                 new PointF(dxmin, dymin),
                 new PointF(dxmax, dymin),
                 new PointF(dxmin, dymax)
            };
            gr.Transform = new Matrix(wrectf, dpts);
        }
        private void CreateBitmap()
        {
            Graphics graphicsObj;
            Holder.bbb.Add(new Bitmap(Parent.f2.ClientRectangle.Width,
                                613 / Holder.ChannelsNumber,
                               System.Drawing.Imaging.PixelFormat.Format24bppRgb));

            graphicsObj = Graphics.FromImage(Holder.bbb[Holder.bbb.Count - 1]);
            graphicsObj.Clear(Color.White);

            Font drawFont = new Font("Arial", 16);
            SolidBrush drawBrush = new SolidBrush(Color.Blue);
            float x = 0;
            float y = 613 / Holder.ChannelsNumber - 20;
            graphicsObj.DrawString("Model_" + Holder.check + "_1", drawFont, drawBrush, x, y);

            graphicsObj.SmoothingMode = SmoothingMode.AntiAlias;
            float MIN_SAMPLE = 0;
            float MAX_SAMPLE = Holder.SamplesNumber;
            float MIN_LEVEL = (float)countsY.Min();
            float MAX_LEVEL = (float)countsY.Max();
            MapRectangles(graphicsObj,
                MIN_SAMPLE, MAX_SAMPLE, MIN_LEVEL, MAX_LEVEL,
                0, Parent.f2.ClientSize.Width, 613 / Holder.ChannelsNumber - 20, 0);

            using (Pen thin_pen = new Pen(Color.Black, 3))
            {
                for (int count = 0; count < Holder.SamplesNumber - 1; count++)
                {
                    graphicsObj.DrawLine(thin_pen, new PointF(count, (float)countsY[count]), new PointF(count + 1, (float)countsY[count + 1]));
                }
            }

            graphicsObj.Dispose();
        }
        private void добавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!Holder.flagSamples && !Holder.flagRate)
            {
                DialogResult result = MessageBox.Show("Добавить к существующему навигационному окну?",
                                "Сообщение",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Information,
                                MessageBoxDefaultButton.Button1,
                                MessageBoxOptions.DefaultDesktopOnly);
                if (result == DialogResult.Yes)
                {
                    this.CreateBitmap();
                }
                else
                {
                    //Parent.f2.Close();
                    if (Holder.bbb != null) {
                        Holder.bbb.Clear();
                        Holder.bbb = null;
                    }
                    if (Holder.Ocsillograms != null)
                    {
                        Holder.Ocsillograms.Clear();
                        Holder.Ocsillograms = null;
                    }
                    if (Holder.CurIndArray != null)
                    {
                        Holder.CurIndArray.Clear();
                        Holder.CurIndArray = null;
                    }
                    Holder.bbb = new List<Bitmap>();
                    this.CreateBitmap();
                }
                Parent.f2.Refresh();
            }
            else
            {
                if (Holder.bbb != null)
                {
                    Holder.bbb.Clear();
                    Holder.bbb = null;
                }
                if (Holder.Ocsillograms != null)
                {
                    Holder.Ocsillograms.Clear();
                    Holder.Ocsillograms = null;
                }
                if (Holder.CurIndArray != null)
                {
                    Holder.CurIndArray.Clear();
                    Holder.CurIndArray = null;
                }
                Holder.bbb = new List<Bitmap>();
                try
                {
                    this.CreateBitmap();
                    Parent.f2.Refresh();
                }
                catch
                {

                }
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Holder.grid = !Holder.grid;
            this.toolStripButton1.Checked = Holder.grid; // кнопка нажата или нет
            chart.ChartAreas["myGraph"].AxisX.MajorGrid.Enabled = !Holder.grid;
            chart.ChartAreas["myGraph"].AxisY.MajorGrid.Enabled = !Holder.grid;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Holder.dots = !Holder.dots;
            this.toolStripButton2.Checked = Holder.dots;
            if (!Holder.dots)
                chart.Series[0].MarkerStyle = MarkerStyle.None;
            else
                chart.Series[0].MarkerStyle = MarkerStyle.Circle;
        }
    }
}
