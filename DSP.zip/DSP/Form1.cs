﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace DSP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            HelpToolStripMenuItem.Click += HelpClick;

            OpenToolStripMenuItem.Click += OpenClick;

            openFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
        }

        void HelpClick(object sender, EventArgs e)
        {
            MessageBox.Show("Выполнили: студенты 2-го курса факультета математики и компьютерных наук Шестопалова А.В., Прохорова Д.Д., Смагина Е.Г.", "Справка");
        }
        Form2 f2;
        void OpenClick(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            // получаем выбранный файл
            string filename = openFileDialog1.FileName;
            // читаем файл в строку
            string[] array = File.ReadAllLines(filename, Encoding.Default);


            //MessageBox.Show("Файл открыт", "Каналы");
            f2 = new Form2(array);
            f2.Show();

        }

    }
}
